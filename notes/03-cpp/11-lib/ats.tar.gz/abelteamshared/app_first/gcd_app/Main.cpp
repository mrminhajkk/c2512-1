#include <iostream>
#include "./../gcdapi/gcd.h"

int main() {
    std::cout << findGCD(12,18) << std::endl;
    return 0;
}