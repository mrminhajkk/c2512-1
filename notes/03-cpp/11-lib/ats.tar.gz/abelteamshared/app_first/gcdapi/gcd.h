#ifndef GCD_H
#define GCD_H
int findGCD(int a, int b);
#endif 