#include <iostream>
#include "./../hcfapi/hcf.h"

int main() {
    std::cout << findHCF(12,18) << std::endl;
    return 0;
}