#include <stdio.h>
extern int findHCF(int a, int b);

int main() {
    printf("hcf: %d\n", findHCF(12, 18));
    return 0;
}
