#ifndef HCF_H
#define HCF_H
extern "C" {
    int findHCF(int a, int b);
}
#endif 